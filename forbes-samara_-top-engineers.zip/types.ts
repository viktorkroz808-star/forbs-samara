
export interface Engineer {
  rank: number;
  name: string;
  netWorth: string;
  source: string;
  imageUrl: string;
}
